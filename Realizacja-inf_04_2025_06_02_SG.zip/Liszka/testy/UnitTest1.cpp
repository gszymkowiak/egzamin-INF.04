#include <string>
#include "pch.h"
#include "CppUnitTest.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

std::string cipher(const std::string& text, const int& key)
{
	if (key == 0) return text;

	std::string newText = "";

	for (int i = 0; i < text.size(); i++)
	{
		int charCode = (int)text[i];
		if (charCode >= 'a' && charCode <= 'z')
		{
			int letter = charCode - 'a';
			letter += key;
			letter %= 26;
			if (letter < 0) letter += 26;
			charCode = letter + 'a';
		}
		newText += (char)charCode;
	}

	return newText;
}

namespace UnitTest1
{
	TEST_CLASS(UnitTest1)
	{
	public:
		
		TEST_METHOD(DanePodstawowe)
		{
			Assert::IsTrue(cipher("abc", 3) == "def");
		}

		TEST_METHOD(Zawijanie)
		{
			Assert::IsTrue(cipher("xyz", 3) == "abc");
		}

		TEST_METHOD(Odszyfrowanie)
		{
			Assert::IsTrue(cipher("def", -3) == "abc");
		}

		TEST_METHOD(KluczWiekszyOdAlfabetu)
		{
			Assert::IsTrue(cipher("abc", 29) == "def");
		}

		TEST_METHOD(SpacjaWTekscie)
		{
			Assert::IsTrue(cipher("ab cd", 2) == "cd ef");
		}
	};
}
