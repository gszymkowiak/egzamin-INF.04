﻿#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

bool powtorka(int liczba, int uzyte_liczby[]) {
	for (int i = 0; i < 6; i++) {
		if (liczba == uzyte_liczby[i]) {
			return true;
		}
	}

	return false;
}

void losowanie(int tablica_losowan[]) {
	int losowa_liczba;
	int uzyte_liczby[6] = {};
	
	for (int j = 0; j < 6; j++) {
		if (j > 0) {
			do {
				losowa_liczba = (rand() % 49) + 1;
			} while (powtorka(losowa_liczba, uzyte_liczby));
		}
		else {
			losowa_liczba = (rand() % 49) + 1;
		}

		uzyte_liczby[j] = losowa_liczba;
		tablica_losowan[j] = losowa_liczba;
	}
}


/*********
nazwa funckji:			wyswietl_losowania
opis funkcji:			funkcja wyświetla wylosowane liczby dla pojedynczej grupy losowania
parametry:				grupa_losowania[] - pojedyncza grupa losowania (pojedyncza tablica z tablicy dwuwymiarowej)
zwracany typ i opis		brak
autor:					12345678901
**********/
void wyswietl_losowania(int grupa_losowania[]) {
	for (int i = 0; i < 6; i++) {
		cout << grupa_losowania[i] << " ";
	}
	cout << endl;
}

int main()
{	

	setlocale(LC_CTYPE, "polish");

	cout << "Ile wygenerować losowań? ";
	int liczba_losowan;
	cin >> liczba_losowan;

	/*Tworzenie tablicy dwuwymiarowej do przechowywania losowań*/
	int const n = 6;
	int** tablica_losowan = new int* [liczba_losowan];

	for (int i = 0; i < liczba_losowan; i++) {
		tablica_losowan[i] = new int[n];
	}

	srand(time(0));

	/*Generowanie losowań*/
	for (int i = 0; i < liczba_losowan; i++) {
		losowanie(tablica_losowan[i]);
	}

	/*Wyświetlenie losowań*/
	for (int i = 0; i < liczba_losowan; i++) {
		cout << "Losowanie " << i + 1 << ": ";
		wyswietl_losowania(tablica_losowan[i]);
	}

	/*Zliczanie wystąpień liczb*/
	for (int szukana_liczba = 1; szukana_liczba < 50; szukana_liczba++) {
		int licznik = 0;
		for (int i = 0; i < liczba_losowan; i++) {
			for (int j = 0; j < 6; j++) {
				if (tablica_losowan[i][j] == szukana_liczba) {
					licznik++;
				}
			}
		}

		cout << "Wystąpienia liczby " << szukana_liczba << ": " << licznik << endl;
	}

	delete[] tablica_losowan;

	system("pause");

}

