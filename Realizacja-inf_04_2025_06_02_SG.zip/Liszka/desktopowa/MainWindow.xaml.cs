﻿using Microsoft.Win32;
using System.IO;
using System.Windows;

namespace WpfApp1
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog dialog = new();
            bool? result = dialog.ShowDialog();
            if (result == true)
            {
                File.WriteAllText(dialog.FileName, OutputBlock.Text);
            }
        }

        private void CipherButton_Click(object sender, RoutedEventArgs e)
        {
            if (!int.TryParse(KeyInput.Text, out int key))
            {
                key = 0;
            }
            string text = TextInput.Text;
            OutputBlock.Text = CipherText(text, key);
        }

        private static string CipherText(string text, int key)
        {
            if (key == 0) return text;
            string newText = "";

            foreach (char c in text)
            {
                int charCode = c;
                if (charCode >= 'a' && charCode <= 'z')
                {
                    int letter = charCode - 'a';
                    letter += key;
                    letter %= 26;
                    if (letter < 0) letter += 26;
                    charCode = letter + 'a';
                }
                newText += (char)charCode;
            }

            return newText;
        }
    }
}