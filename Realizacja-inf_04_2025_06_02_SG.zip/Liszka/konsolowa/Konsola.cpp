﻿#include <iostream>
#include <string>

std::string cipher(const std::string& text, const int& key)
{
	if (key == 0) return text;

	std::string newText = "";

	for (int i = 0; i < text.size(); i++)
	{
		int charCode = (int)text[i];
		if (charCode >= 'a' && charCode <= 'z')
		{
			int letter = charCode - 'a';
			letter += key;
			letter %= 26;
			if (letter < 0) letter += 26;
			charCode = letter + 'a';
		}
		newText += (char)charCode;
	}

	return newText;
}

int main()
{
    setlocale(LC_ALL, "Polish");

    std::string text;
    int key = 0;

    std::cout << "Wprowadź tekst: ";
    std::getline(std::cin, text);
    std::cout << "Wprowadź klucz: ";
    std::cin >> key;

    std::string newText = cipher(text, key);
    std::cout << "Tekst zaszyfrowany: " << newText << std::endl;

    system("pause");
}