﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace kolory
{
    /// <summary>
    /// Logika interakcji dla klasy MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            slider_r.Value = 255;
            slider_g.Value = 255;
            slider_b.Value = 255;
        }

        private void Slider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            byte r = (byte)slider_r.Value;
            byte g = (byte)slider_g.Value;
            byte b = (byte)slider_b.Value;

            label_r.Content = r;
            label_g.Content = g;
            label_b.Content = b;

            Color kolor = Color.FromRgb(r, g, b);
            rectangle.Fill = new SolidColorBrush(kolor);
        }

        private void btn_change_Click(object sender, RoutedEventArgs e)
        {
            byte r = (byte)slider_r.Value;
            byte g = (byte)slider_g.Value;
            byte b = (byte)slider_b.Value;

            label_inside.Content = $"{r}, {g}, {b}";

            label_r.Content = r;
            label_g.Content = g;
            label_b.Content = b;

            Color kolor = Color.FromRgb(r, g, b);
            small_rectangle.Fill = new SolidColorBrush(kolor);
        }
    }
}
